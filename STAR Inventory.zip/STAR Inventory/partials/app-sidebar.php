<div class="dashboard_sidebar" id="dashboard_sidebar">
        <h3 class="dashboard_logo" id="dashboard_logo">STAR</h3>
       <div class="dashboard_sidebar_user">
        <img src="images/avatar.png" alt="User Image" id="UserImage"/>
        <span><?= $admin['first-name'] . ' ' . $admin['last-name'] ?></span>
       </div>
       <div class="dashboard_sidebar_menus">
            <ul class="dashboard_menu_lists">
            <!-- class="menuActive" -->
                <li>
                    <a href="./dashboard.php"><i class="fa fa-dashboard"></i> <span class="menuText">Dashboard</span></a>
                </li>
                <li>
                    <a href="./dashboard.php"><i class="fa fa-file-o"></i> <span class="menuText">REPORTS</span></a>
                </li>
                <li>
                    <a href="./dashboard.php"><i class="fa fa-tag"></i> <span class="menuText">PRODUCTS</span></a>
                </li>
                <li>
                    <a href="./dashboard.php"><i class="fa fa-truck"></i> <span class="menuText">SUPPLIERS</span></a>
                </li>
                <li>
                    <a href="./dashboard.php"><i class="fa fa-cart-plus"></i> <span class="menuText">PURCHSE ORDER</span></a>
                </li>
                <li>
                    <a href="./admins-add.php"><i class="fa fa-user-plus"></i> <span class="menuText">Add Admin</span></a>
                </li>
               
            </ul>
       </div>
     </div>