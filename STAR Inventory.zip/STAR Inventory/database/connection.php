<?php 
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'inventory'; // Added the missing variable $dbname

    // Connection
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) { // Changed from \Exception to PDOException
        // Handle the exception here
         $error_message = $e->getMessage();
    }
?>      
