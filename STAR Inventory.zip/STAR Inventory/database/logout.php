<?php
    session_start();

    //remove all session variable
    session_unset();

    //destroy
    session_destroy();
    header('location: ../login.php');
?>