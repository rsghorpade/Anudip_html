<?php 
    //start session
    session_start();

     $table_name = $_SESSION['table'];
   //  $_SESSION['table'] = '';
     $first_name = $_POST['first_name'];
     $last_name = $_POST['last_name'];
     $email = $_POST['email'];
     $password = $_POST['password'];
     $encrypted = password_hash($password, PASSWORD_DEFAULT);
     //Adding records
    try {
    $command = "INSERT INTO $table_name(first_name, last_name, email, password, created_at, updated_at)
                                VALUES 
                                    ('".$first_name."', '".$last_name."', '".$email."', '".$encrypted."', NOW(), NOW())";

//var_dump($command);die;
    include('connection.php');
    $conn->exec($command);   
    $response = [
        'success' => true,
        'message' => $first_name . ' ' . $last_name . ' Successfully added to the system.'
    ];
} catch (PDOException $e) {
    $reponse = [
    'success' => false,
    'message' => $e->getMessage()
    ];
}
   $_SESSION['response'] = $response;
   header('location: ../admins-add.php');
?>


